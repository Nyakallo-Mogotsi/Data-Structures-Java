
/**
 * Write a description of class recursive here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class recursiveSort
{
    public QueueAsMyLinkedList<Integer> recursive(QueueAsMyLinkedList<Integer> pl, int x)
    {
        
        int split=x / 2;
        
        QueueAsMyLinkedList<Integer> Queue1 = new QueueAsMyLinkedList<>();
        
        QueueAsMyLinkedList<Integer> Queue2 = new QueueAsMyLinkedList<>();
        
        QueueAsMyLinkedList<Integer> sorted = new QueueAsMyLinkedList<>();
        
        if (x <= 1) {
            return pl; // Base case: already sorted
        }
        
        for (int i = 0; i < split; i++)
        {
            Queue1.enqueue(pl.dequeue());
        }
        for (int i = split; i < x; i++)
        {
            Queue2.enqueue(pl.dequeue());
        }
    
        Queue1 = recursive(Queue1, split);
        Queue2 = recursive(Queue2, x - split);
        
    
        while (!Queue1.isEmpty() && !Queue2.isEmpty())
        {
            if (Queue1.getFirst().compareTo(Queue2.getFirst()) <= 0)
            {
                sorted.enqueue(Queue1.dequeue());
            }
            else
            {
                sorted.enqueue(Queue2.dequeue());
            }
        }
    
        // Add remaining elements, if any
        while (!Queue1.isEmpty())
        {
            sorted.enqueue(Queue1.dequeue());
        }
        while (!Queue2.isEmpty())
        {
            sorted.enqueue(Queue2.dequeue());
        }
    
        return sorted;
    }
}
